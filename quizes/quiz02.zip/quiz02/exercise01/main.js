function showFox() {
    console.log('Change image and paragraph to fox...');
    document.querySelector("p").innerHTML = 'fox';
    document.querySelector("img").src = 'images/fox.jpg';
}
function showLion() {
    console.log('Change image and paragraph to lion...');
    document.querySelector("p").innerHTML = 'lion';
    document.querySelector("img").src = 'images/lion.jpg';
}
function showTiger() {
    console.log('Change image and paragraph to tiger...');
    document.querySelector("p").innerHTML = 'tiger';
    document.querySelector("img").src = 'images/tiger.png';
}
function showZebra() {
    console.log('Change image and paragraph to zebra...');
    document.querySelector("p").innerHTML = 'zebra';
    document.querySelector("img").src = 'images/zebra.jpg';
}